<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Student Data Management System (SDMS)</title>
    <link rel="stylesheet" href="/css/dashboard.css">
</head>
<body>
    <!-- Navigation Panel -->
    <nav>
        <div class="nav-container">
            <div class="logo">Student Data Management System</div>
            <ul class="nav-links">
                <li><a href="#">Profile</a></li>
                <li><a href="<?php echo e(route('student.logout')); ?>">Logout</a></li>
            </ul>
        </div>
    </nav>

    <!-- Dashboard Container -->
    <div class="dashboard-container">
        <h1 class="dashboard-title">Welcome, <?php echo e(Auth::user()->name); ?> </h1>
        <h5 class="you">You are logged in !</h5>
        <div class="cards-container">
            <div class="card student-card">
                <h2><a href = "<?php echo e(route('dash.achieve')); ?>"> Student Achievements</a></h2>
            </div>
            <div class="card teacher-card">
                <h2><a href = "<?php echo e(route('dash.internship')); ?>"> Student Internships</a></h2>
            </div>
            <div class="card staff-card">
                <h2><a href = "<?php echo e(route('dash.courses')); ?>"> Student Courses & Workshop</a></h2>
                
            </div>
            <div class="card principal-card">
                <h2><a href = "<?php echo e(route('dash.paper')); ?>"> Student Paper Publications</a></h2>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\projectinternship\intership_project\resources\views/student/dashboard.blade.php ENDPATH**/ ?>