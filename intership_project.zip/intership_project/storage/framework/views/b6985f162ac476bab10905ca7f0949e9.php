<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Internship Details</title>
    <link rel="stylesheet" href="/css/achieve.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <div class="nav-container">
            <div class="logo">Student Data Management System</div>
            <ul class="nav-links">
                <li><a href="<?php echo e(route('student.dashboard')); ?>">Dashboard</a></li>
                <li><a href="#">Profile</a></li>
                <li><a href="<?php echo e(route('student.logout')); ?>">Logout</a></li>
            </ul>
        </div>
    </nav>

    <!-- Container for Table -->
    <div class="container">
        <h1>Students Internship</h1>
        <div class="horizontal-container">
        <form action="<?php echo e(route('dash.internshipadd')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <button class="add-btn" >Add New Entry</button>
            </form>            <form action="<?php echo e(route('dash.internship')); ?>" method="get">
                <input type="search" name = "search" placeholder="Search "  style="width:400px; height:30px;" value="<?php echo e($search); ?>">
                <button class="add-btn" >Search</button>
                <a href="<?php echo e(route('dash.internship')); ?>">
                    <button class="add-btn" type="button">Reset</button>
                </a>

            </form>
        </div>
        <table id="dataTable">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Roll no</th>
                    <th>Department</th>
                    <th>Year of Study</th>
                    <th>Name of Organization</th>
                    <th>Internship Date (From)</th>
                    <th>Internship Date (To)</th>
                    <th>Intership Certificate</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <!-- Sample Row -->
                <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
               
                        <td><?php echo e($entry->name); ?></td>
                        <td><?php echo e($entry->roll); ?></td>
                        <td><?php echo e($entry->dept); ?></td>
                        <td><?php echo e($entry->year); ?></td>
                        <td><?php echo e($entry->organization); ?></td>
                        <td><?php echo e($entry->start); ?></td>
                        <td><?php echo e($entry->end); ?></td>
                        <td>
                            <img src = "<?php echo e(asset($entry->certificate)); ?>" style = "width:70px ; height:70px;" alt="Img">
                        </td>
                        <td>
                        <div class="horizontal-column">
                            <form action="<?php echo e(route('dash.internshipedit', $entry->id)); ?>" method="get">
                                <button class="edit-btn">Edit</button>
                                
                            </form>
                            <form action="<?php echo e(route('dash.idestroy', $entry->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>                                
                                <button class="delete-btn">Delete</button>
                                
                            </form>
                            <form action="<?php echo e(route('dash.internshipview', $entry->id)); ?>" method="get">
                                    <button class="add-btn">View</button>  
                            </form>
                        </div>
                        </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tr>
            </tbody>
        </table>
    </div>
 <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
 <?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\projectinternship\intership_project\resources\views/dash/internship.blade.php ENDPATH**/ ?>