<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Achievement Add Details</title>
    <link rel="stylesheet" href="/css/add.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <div class="nav-container">
            <div class="logo">Student Data Management System</div>
            <ul class="nav-links">
                <li><a href="<?php echo e(route('student.dashboard')); ?>">Dashboard</a></li>
                <li><a href="#">Logout</a></li>

            </ul>
        </div>
    </nav>

    <!-- Container for Table -->
    <div class="form-container">
        <h2>Edit Achievement Data</h2>
        <form action="<?php echo e(route('dash.achieveupdate', ['newentries' => $newentries->id])); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?> <!-- Use PUT for updates -->
            
            <label for="name">Name<span style="color: red;">*</span></label>
            <input type="text" id="name" name="name" placeholder="Enter Name" value="<?php echo e(old('name', $newentries->name)); ?>" required>

            <label for="roll">Roll number<span style="color: red;">*</span></label>
            <input type="text" id="roll" name="roll" placeholder="Enter Roll no" value="<?php echo e(old('roll', $newentries->roll)); ?>" required>

            <label for="dept">Department<span style="color: red;">*</span></label>
            <select id="dept" name="dept" required>
                <option value="">--Select--</option>
                <option value="IT" <?php echo e($newentries->dept == 'IT' ? 'selected' : ''); ?>>IT</option>   <!-- If the condition is true ($newentries->dept == 'IT') then it will preselect the 'IT' if false then ''(noting)-->
                <option value="EXTC" <?php echo e($newentries->dept == 'EXTC' ? 'selected' : ''); ?>>EXTC</option>
                <option value="COMP" <?php echo e($newentries->dept == 'COMP' ? 'selected' : ''); ?>>Computer</option>
                <option value="Mechanical" <?php echo e($newentries->dept == 'Mechanical' ? 'selected' : ''); ?>>Mechanical</option>
                <option value="Chemical" <?php echo e($newentries->dept == 'Chemical' ? 'selected' : ''); ?>>Chemical</option>
                <option value="Electrical" <?php echo e($newentries->dept == 'Electrical' ? 'selected' : ''); ?>>Electrical</option>
            </select>

            <label for="indexing">Year of Study<span style="color: red;">*</span></label>
            <select id="indexing" name="year" required>
                <option value="">--Select--</option>
                <option value="FE" <?php echo e($newentries->year == 'FE' ? 'selected' : ''); ?>>FE</option>
                <option value="SE" <?php echo e($newentries->year == 'SE' ? 'selected' : ''); ?>>SE</option>
                <option value="TE" <?php echo e($newentries->year == 'TE' ? 'selected' : ''); ?>>TE</option>
                <option value="BE" <?php echo e($newentries->year == 'BE' ? 'selected' : ''); ?>>BE</option>
            </select>

            <label for="na">Name of Activity<span style="color: red;">*</span></label>
            <input type="text" id="na" name="activity" placeholder="Activity" value="<?php echo e(old('activity', $newentries->activity)); ?>" required>

            <label for="aw">Award won</label>
            <input type="text" id="aw" name="award" placeholder="Name the Award" value="<?php echo e(old('award', $newentries->award)); ?>">

            <label for="certificate">Certificate</label>
            <input type="file" id="certificate" name="certificate">

            <div class="form-buttons">
                <button type="submit" class="save-btn">Update</button>
            </div>
        </form>

    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\projectinternship\intership_project\resources\views\dash\achieveedit.blade.php ENDPATH**/ ?>