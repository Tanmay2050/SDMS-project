<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Internship Add Details</title>
    <link rel="stylesheet" href="/css/add.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <div class="nav-container">
            <div class="logo">Student Data Management System</div>
            <ul class="nav-links">
                <li><a href="<?php echo e(route('student.dashboard')); ?>">Dashboard</a></li>
                <li><a href="#">Logout</a></li>
            </ul>
        </div>
    </nav>

    <!-- Container for Table -->
    <div class="form-container">
        <h2>Edit Internship Data</h2>
        <form action="<?php echo e(route('dash.internshipupdate',['newentries' => $newentries])); ?>" method="post" enctype = "multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <label for="name">Name</label>
            <input type="text" id="name" name="name" placeholder="Enter Name" value="<?php echo e(old('name' , $newentries->name)); ?>" required>

            <label for="roll">Roll number</label>
            <input type="text" id="roll" name="roll" placeholder="Enter Roll no" value="<?php echo e(old('roll' , $newentries->roll)); ?>" required>

            <label for="dept">Department</label>
            <select id="dept" name="dept" required>
                <option value="">--Select--</option>
                <option value="IT" <?php echo e($newentries->dept == 'IT' ? 'selected' : ''); ?> >IT</option>
                <option value="EXTC" <?php echo e($newentries->dept == 'EXTC' ? 'selected' : ''); ?>>EXTC</option>
                <option value="COMP" <?php echo e($newentries->dept == 'COMP' ? 'selected' : ''); ?>>Computer</option>
                <option value="Mechanical" <?php echo e($newentries->dept == 'Mechanical' ? 'selected' : ''); ?>>Mechanical</option>
                <option value="Chemical" <?php echo e($newentries->dept == 'Chemical' ? 'selected' : ''); ?>>Chemical</option>
                <option value="Electrical" <?php echo e($newentries->dept == 'Electrical' ? 'selected' : ''); ?>>Electrical</option>

            </select>

            <label for="indexing">Year of Study</label>
            <select id="indexing" name="year" required>
                <option value="">--Select--</option>
                <option value="FE" <?php echo e($newentries->year == 'FE' ? 'selected' : ''); ?>>FE</option>
                <option value="SE" <?php echo e($newentries->year == 'SE' ? 'selected' : ''); ?>>SE</option>
                <option value="TE" <?php echo e($newentries->year == 'TE' ? 'selected' : ''); ?>>TE</option>
                <option value="BE" <?php echo e($newentries->year == 'BE' ? 'selected' : ''); ?>>BE</option>


            </select>

            <label for="aw">Name of Organization</label>
            <input type="text" id="aw" name="organization" placeholder="Organization/Institute" value="<?php echo e(old('organization' , $newentries->organization)); ?>" required>

            <label for="aw">Stating Date</label>
            <input type="Date" id="aw" name="start" placeholder="From" value="<?php echo e(old('start' , $newentries->start)); ?>" required>
            <label for="aw">Ending Date </label>
            <input type="Date" id="aw" name="end" placeholder="To" value="<?php echo e(old('end' , $newentries->end)); ?>" required>

            <label for="certificate">Certificate</label>
            <input type="file" id="certificate" name="certificate">

            <div class="form-buttons">
                <button type="submit" class="save-btn">Update</button>
            </div>
        </form>
    </div>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
 <?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\projectinternship\intership_project\resources\views\dash\internshipedit.blade.php ENDPATH**/ ?>